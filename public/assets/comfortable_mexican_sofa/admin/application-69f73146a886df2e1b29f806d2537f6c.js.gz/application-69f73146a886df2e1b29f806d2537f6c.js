// Overwrite this file in your application /app/assets/javascripts/comfortable_mexican_sofa/admin/application.js 
;
